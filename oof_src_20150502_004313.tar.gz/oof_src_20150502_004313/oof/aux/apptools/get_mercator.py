import os
import numpy as np
import datetime

from okean import roms, netcdf, dateu
from okean.datasets import hycom
from okean.roms.inputs import prognostic

sparams = 6., 0.2, 40., 30,   2,1
tunits  = 'days since 1970-01-01'
obc='nsw'



dest=''
#ob=prognostic.DataAccess(xdim='X',ydim='Y',zdim='Depth',tdim='MT',
#                x_name='Longitude',y_name='Latitude',z_name='Depth',
#                temp_name='temperature',salt_name='salinity',u_name='u',
#                v_name='v',ssh_name='ssh',time_name='MT')

ob=prognostic.DataAccess(xdim='x',ydim='y',zdim='deptht',tdim='time_counter',
                x_name='nav_lon',y_name='nav_lat',z_name='deptht',
                temp_name='votemper',salt_name='vosaline',u_name='vozocrtx',
                v_name='vomecrty',ssh_name='sossheig',time_name='time_counter')

#def source(date):
#  if date>=datetime.datetime(2014,4,05): # worked without this until day 13 apr 2014
#    u='http://tds.hycom.org/thredds/dodsC/GLBa0.08/expt_91.1'
#  elif date>=datetime.datetime(2013,8,21):
#    u='http://tds.hycom.org/thredds/dodsC/GLBa0.08/expt_91.0'
#  else: u='http://tds.hycom.org/thredds/dodsC/glb_analysis'
#  f={}
#  for i in ('temp','salt','u','v','ssh','misc'):
#    f[i]=u
#
#  return f

def source(date):
  date1=date+datetime.timedelta(days=1) # for some reason 31-dez is in next year folder !
  p='/alpendre/mercator_psy2/PSY2V4R4/%d'%date1.year

  f={}
  s='ext-PSY2V4R4_1dAV_%s_%s_grid'%(date.strftime('%Y%m%d'),date1.strftime('%Y%m%d'))
  f['temp'] = os.path.join(p,s+'T_*')
  f['salt'] = os.path.join(p,s+'S_*')
  f['u']    = os.path.join(p,s+'U_*')
  f['v']    = os.path.join(p,s+'V_*')
  f['ssh']  = os.path.join(p,s+'2D_*')
  f['misc'] = f['temp']

  return f


def is_ready(date0,date1=None,check1=False):
  if not date1: date1=date0

  # data is at 12h, so rm 12h and add 2 days:
  date0=date0-datetime.timedelta(days=0.5)
  date1=date1+datetime.timedelta(days=2) # this is ok for analysis Only!

  f0 = source(date0)['temp']
  f1 = source(date1)['temp']
  t0=netcdf.nctime(f0,ob.time_name)
  if f0==f1: t1=t0
  else: t1=netcdf.nctime(f1,ob.time_name)

  if check1:
    return (date0>=t0[0]) & (date1<=t1[-1])
  else:
    return date0>=t0[0]


def add_surface(clm,data,create):
  nc=netcdf.Pync(clm,'a')

  # current tind:
  tind=nc.dims['time']-1

  if create:
    nc.add_dim('x_original',data['NX'])
    nc.add_dim('y_original',data['NY'])
    nc.add_dim('z_original',data['NZ'])

    x=nc.add_var('x_original',np.dtype('d'),('y_original','x_original'))
    y=nc.add_var('y_original',np.dtype('d'),('y_original','x_original'))
    x._nc[:]=data['lon']
    y._nc[:]=data['lat']

  for v in 'temp','salt','u','v','zeta':
    vname=v+'_'+'original'
    if create:
      var=nc.add_var(vname,np.dtype('d'),('time','y_original','x_original'))


    if v=='zeta':
      nc.vars[vname]._nc[tind,...]=data['ssh'][:]
    else:
      nc.vars[vname]._nc[tind,...]=data[v][0,:,:]

  nc.close()


def gen_clm_bry(clmname,bryname,grd,date0,date1=None,quiet=0):
  if not date1:
    # data is at 12h, so remove and add one day
    date0=date0-datetime.timedelta(days=0.5)
    date1=date0+datetime.timedelta(days=2)


  # inds settings:
  g=roms.Grid(grd)
  if 1:
    # too slow for global datasets!
    xlim=g.lon.min(),g.lon.max()
    ylim=g.lat.min(),g.lat.max()
    inds={ob.xdim:xlim,ob.ydim:ylim}
#  else:
#    here=os.path.dirname(__file__)
#    fsave=os.path.join(here,'ijinds.pickle')
#    if os.path.isfile(fsave):
#      i1,i2,j1,j2=np.load(fsave)
#    else:
#      f='http://tds.hycom.org/thredds/dodsC/glb_analysis'
#      lon=netcdf.use(f,'Longitude')
#      lat=netcdf.use(f,'Latitude')
#
#      lon=np.mod(lon,360)
#      xlim=g.lon.min(),g.lon.max()
#      ylim=g.lat.min(),g.lat.max()
#      if np.any(g.lon<0): lon=lon-360. # this may be not so simple!
#      i1,i2,j1,j2=hycom.get_ij(lon,lat,xlim,ylim)
#
#      np.array([ i1-1,i2+1,j1-1,j2+1]).dump(fsave)
#
#    xlim=str(i1[0])+':'+str(i2[0])
#    ylim=str(j1[0])+':'+str(j2[0])
#    inds={ob.xdim:xlim,ob.ydim:ylim}



  create=True

  dates=dateu.drange(date0,date1,True)

  Cargs={}
  Cargs['title']  = 'mch climatology file from HYCOM, dates=%s to %s' % (date0.isoformat(' '),date1.isoformat(' '))
  Cargs['tunits'] = tunits
  Cargs['create'] = create

  Bargs={}
  Bargs['title']  = 'mch boundary file from HYCOM, dates=%s to %s' % (date0.isoformat(' '),date1.isoformat(' '))
  Bargs['tunits'] = tunits
  Bargs['create'] = create
  Bargs['obc'] = obc


  # first date: may not be present !
  if not quiet: print 'first date...'
  Date0=dates[0]
  d=Date0
  found=0
  for nAtt in range(7): # try 6 days before!
    d=dateu.next_date(Date0,-nAtt)
    if not quiet: print '  --> %s' % d.isoformat(' ')
    f=source(d)
    inds[ob.tdim]=d

    try:
      Data0,msg=prognostic.load_data(f,quiet=quiet,settings=ob,inds=inds)
      if not msg:
        found=1
        break
      elif not quiet: print ' => ',msg
    except: pass

  if not found: return 'cannot find first date'

  if not quiet: print 'last date...'
  # last date:
  Date1=dates[-1]
  d=Date1
  found=0
  for nAtt in range(7): # try 6 days after!
    d=dateu.next_date(Date1,nAtt)
    if not quiet: print '  --> %s' % d.isoformat(' ')
    f=source(d)
    inds[ob.tdim]=d

    try:
      Data1,msg=prognostic.load_data(f,quiet=quiet,settings=ob,inds=inds)
      if not msg:
        found=1
        break
      elif not quiet: print ' => ',msg
    except: pass

  #if not found: return 'cannot find last date'
  if not found:
    if not quiet: print 'not using last date'
    Data1=False

  # other dates:
  for d in dates:
    if d==dates[0]: Data=Data0
    elif d==dates[-1]:
      Data=Data1
      if Data is False: continue
    else:
      f=source(d)
      inds[ob.tdim]=d

      found=0
      msg='unknown error'
      try:
        Data,msg=prognostic.load_data(f,quiet=quiet,settings=ob,inds=inds)
        if not msg: found=1
      except: pass
      if not found:
        if not quiet: print 'CANNOT use date ',d
        continue

#    if np.any(g.lon<0): Data['lon']=Data['lon']-360. # this may be not so simple!
    # clim:
    data,HA=prognostic.data2roms(Data,grd,sparams,quiet=quiet,horizAux=True)
    prognostic.make_clm(clmname,data,grd,sparams,quiet=quiet,**Cargs)

    # bry:
    data=prognostic.data2romsbry(Data,grd,sparams,quiet=quiet,horizAux=HA)
    prognostic.make_bry(bryname,data,grd,sparams,quiet=quiet,**Bargs)

    # add surface original data to clm file:
    add_surface(clmname,Data,Cargs['create'])

    if create:
      Cargs['create']=False
      Bargs['create']=False

  # add dyes:
  #add_dyes(bryname)

  return ''

if __name__=='__main__':
  grd='/data/Rutgers3.7.Operational//Forecast//inputs/opbig_hanning5_hmin40_grd_rutg3.7_newrivers.nc'
  date0=datetime.datetime(2015,02,01)

  gen_clm_bry('clm.nc','bry.nc',grd,date0,date1=None,quiet=0)
