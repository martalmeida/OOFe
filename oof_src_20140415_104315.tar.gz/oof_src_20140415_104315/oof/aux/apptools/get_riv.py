
''' ************** THIS FILE IS JUST AN EXAMPLE **************** '''

import numpy as np
from okean.roms.inputs import rivers
from okean import cookbook as cb
import string
import datetime
from okean import netcdf

nlevels = 30
salt    = 0


Rivers=cb.odict()

#                           xi   eta   dir  signal
Rivers['Esmeraldas']    =  286,  129,  1,   1
Rivers['Guayas']        =  281,   59,  1,  -1

nrivers = len(Rivers.keys())

info={}
info['river_names']=string.join(Rivers.keys(),', ')
info['runoff_type']='Climatological'

args={}
args['tunits'] = 'days since 1970-01-01 00:00:00'
args['title']  = 'Ecuador CLM river frc'
args['attr']   = info



def get_riv(date):
  pass
  riv={}
  return time, riv


def get_temp(date):
  pass
  return time, temp


def gen_frc(fname,grid,date0,date1,**kargs):
  r=rivers.RiverFrc(fname,grid,nrivers,nlevels,**kargs)
  r.create()

  time,temp=get_temp()

  # fill rivers:
  vshape=rivers.gen_vshape(nlevels,'linear')


  time,riv=get_riv()()

  for k in riv.keys():
    xi,eta,d,sig=Rivers[k]
    Rivers[k]=riv[k]*sig,temp,salt,vshape,xi,eta,d

  Rivers['time']=time
  r.fill(Rivers,quiet=0)


